# zsc-common — 公共基础设施

**被所有模块依赖**的最底层模块，提供注解、基类、工具类、统一响应、枚举。无外部业务依赖。

## 核心内容

```
annotation/    ← @Log, @RateLimiter, @RepeatSubmit, @DataScope, @Sensitive, @Anonymous, @Excel
core/
  controller/BaseController.java   ← 所有 Controller 的基类（startPage/getDataTable/success/error）
  domain/AjaxResult.java           ← 系统模块统一响应 {code, msg, data}
  domain/BaseEntity.java           ← 实体基类（createBy/createTime/updateBy/updateTime/remark）
  domain/TreeEntity.java           ← 树形实体基类（含 parentId/ancestors）
  domain/entity/                   ← 核心系统实体：SysUser, SysRole, SysDept, SysMenu, SysDict*
  domain/model/LoginUser.java      ← 登录用户模型（存 Redis，含 roles + permissions 集合）
  page/TableDataInfo.java          ← 分页响应 {code, msg, rows, total}
  page/TableSupport.java           ← 分页入参构建工具
enums/        ← BusinessType, UserStatus, HttpMethod, LimitType, OperatorType...
utils/        ← SecurityUtils, StringUtils, ExcelUtil(poi), 通用工具类包
exception/    ← 业务异常体系（用户/文件/任务/服务/DemoMode/全局异常）
filter/       ← XSS 过滤, RepeatableRequest 等 Servlet Filter
```

## 关键约定

- `SysUser.isAdmin()`：按角色 `role_key='admin'` 判断（兼容旧 user_id==1 逻辑）
- 统一响应：系统模块用 `AjaxResult`，业务模块(zsc-module)用自己的一套 `ResultVo`
- 实体继承：普通表实体 extends `BaseEntity`，树形表 extends `TreeEntity`
- 脱敏：`@Sensitive` 注解 + `SensitiveJsonSerializer` Jackson 序列化
- Excel：`@Excel` 注解 + `ExcelUtil.exportExcel()/importExcel()`

[//]: # (  package com.zsc.module.service.impl;)

[//]: # ()
[//]: # (import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;)

[//]: # (import com.baomidou.mybatisplus.extension.plugins.pagination.Page;)

[//]: # (import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;)

[//]: # (import com.zsc.common.utils.SecurityUtils;)

[//]: # (import com.zsc.module.common.exception.ServiceException;)

[//]: # (import com.zsc.module.common.pagination.PageResult;)

[//]: # (import com.zsc.module.domain.dto.BizBillDto;)

[//]: # (import com.zsc.module.domain.dto.BizBillReviewDto;)

[//]: # (import com.zsc.module.domain.dto.query.BizBillQueryDto;)

[//]: # (import com.zsc.module.domain.entity.BizAuditLog;)

[//]: # (import com.zsc.module.domain.entity.BizBill;)

[//]: # (import com.zsc.module.domain.entity.BizBillFile;)

[//]: # (import com.zsc.module.domain.entity.BizCategory;)

[//]: # (import com.zsc.module.domain.vo.BizAuditLogVo;)

[//]: # (import com.zsc.module.domain.vo.BizBillDetailVo;)

[//]: # (import com.zsc.module.domain.vo.BizBillFileVo;)

[//]: # (import com.zsc.module.domain.vo.BizBillVo;)

[//]: # (import com.zsc.module.domain.vo.ReviewerStatsVo;)

[//]: # (import com.zsc.module.domain.vo.TrendItemVo;)

[//]: # (import com.zsc.module.domain.vo.UserBillStatsVo;)

[//]: # (import com.zsc.module.mapper.BizAuditLogMapper;)

[//]: # (import com.zsc.module.mapper.BizBillFileMapper;)

[//]: # (import com.zsc.module.mapper.BizBillMapper;)

[//]: # (import com.zsc.module.mapper.BizCategoryMapper;)

[//]: # (import com.zsc.module.service.BizBillService;)

[//]: # (import org.apache.commons.lang3.StringUtils;)

[//]: # (import org.springframework.beans.BeanUtils;)

[//]: # (import org.springframework.beans.factory.annotation.Autowired;)

[//]: # (import org.springframework.stereotype.Service;)

[//]: # (import org.springframework.transaction.annotation.Transactional;)

[//]: # ()
[//]: # (import java.text.SimpleDateFormat;)

[//]: # (import java.util.Calendar;)

[//]: # (import java.util.ArrayList;)

[//]: # (import java.util.Date;)

[//]: # (import java.util.LinkedHashMap;)

[//]: # (import java.util.List;)

[//]: # (import java.util.Map;)

[//]: # (import java.util.stream.Collectors;)

[//]: # ()
[//]: # (/**)

[//]: # (* 票据表 服务实现类)

[//]: # (  */)

[//]: # (  @Service)

[//]: # (  @Transactional)

[//]: # (  public class BizBillServiceImpl extends ServiceImpl<BizBillMapper, BizBill> implements BizBillService {)

[//]: # ()
[//]: # (  @Autowired)

[//]: # (  private BizBillFileMapper fileMapper;)

[//]: # ()
[//]: # (  @Autowired)

[//]: # (  private BizAuditLogMapper auditLogMapper;)

[//]: # ()
[//]: # (  @Autowired)

[//]: # (  private BizCategoryMapper categoryMapper;)

[//]: # ()
[//]: # (  /**)

[//]: # (    * 管理员禁止执行用户专属操作)

[//]: # (      */)

[//]: # (      private void checkNotAdmin&#40;&#41; {)

[//]: # (      if &#40;SecurityUtils.hasPermi&#40;"biz:bill:review"&#41;&#41; {)

[//]: # (      throw new ServiceException&#40;"管理员不能执行用户操作！"&#41;;)

[//]: # (      })

[//]: # (      })

[//]: # ()
[//]: # (  // ==================== 新增 ====================)

[//]: # ()
[//]: # (  @Override)

[//]: # (  public void addBill&#40;BizBillDto dto&#41; {)

[//]: # (  checkNotAdmin&#40;&#41;;)

[//]: # (  BizBill bill = new BizBill&#40;&#41;;)

[//]: # (  BeanUtils.copyProperties&#40;dto, bill&#41;;)

[//]: # ()
[//]: # (       bill.setCreateBy&#40;SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (       bill.setCreateTime&#40;new Date&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       // 先保存草稿（用临时编号占位），再根据状态替换为正式编号)

[//]: # (       bill.setBillNo&#40;"DRAFT-" + System.currentTimeMillis&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       if &#40;!this.save&#40;bill&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"系统错误，票据保存失败！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       if &#40;"1".equals&#40;dto.getStatus&#40;&#41;&#41;&#41; {)

[//]: # (           bill.setBillNo&#40;generateBillNo&#40;bill.getId&#40;&#41;&#41;&#41;;)

[//]: # (           this.updateById&#40;bill&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 保存附件记录)

[//]: # (       saveAttachments&#40;bill.getId&#40;&#41;, dto.getAttachment&#40;&#41;&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (  // ==================== 查询列表 ====================)

[//]: # ()
[//]: # (  @Override)

[//]: # (  public PageResult<BizBillVo> queryBills&#40;BizBillQueryDto dto&#41; {)

[//]: # (  LambdaQueryWrapper<BizBill> wrapper = new LambdaQueryWrapper<>&#40;&#41;;)

[//]: # ()
[//]: # (       // 普通用户只查自己的票据)

[//]: # (       if &#40;!SecurityUtils.hasPermi&#40;"biz:bill:review"&#41;&#41; {)

[//]: # (           wrapper.eq&#40;BizBill::getCreateBy, SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 条件过滤)

[//]: # (       if &#40;StringUtils.isNotBlank&#40;dto.getKeywords&#40;&#41;&#41;&#41; {)

[//]: # (           wrapper.and&#40;w -> w)

[//]: # (               .like&#40;BizBill::getTitle, dto.getKeywords&#40;&#41;&#41;)

[//]: # (               .or&#40;&#41;)

[//]: # (               .like&#40;BizBill::getBillNo, dto.getKeywords&#40;&#41;&#41;)

[//]: # (           &#41;;)

[//]: # (       })

[//]: # (       wrapper.eq&#40;dto.getCategoryId&#40;&#41; != null, BizBill::getCategoryId, dto.getCategoryId&#40;&#41;&#41;)

[//]: # (              .eq&#40;StringUtils.isNotBlank&#40;dto.getStatus&#40;&#41;&#41;, BizBill::getStatus, dto.getStatus&#40;&#41;&#41;)

[//]: # (              .like&#40;StringUtils.isNotBlank&#40;dto.getAuditBy&#40;&#41;&#41;, BizBill::getAuditBy, dto.getAuditBy&#40;&#41;&#41;)

[//]: # (              .like&#40;StringUtils.isNotBlank&#40;dto.getCreateBy&#40;&#41;&#41;, BizBill::getCreateBy, dto.getCreateBy&#40;&#41;&#41;)

[//]: # (              .ge&#40;dto.getMinAmount&#40;&#41; != null, BizBill::getAmount, dto.getMinAmount&#40;&#41;&#41;)

[//]: # (              .le&#40;dto.getMaxAmount&#40;&#41; != null, BizBill::getAmount, dto.getMaxAmount&#40;&#41;&#41;)

[//]: # (              .ge&#40;StringUtils.isNotBlank&#40;dto.getStartTime&#40;&#41;&#41;, BizBill::getCreateTime, dto.getStartTime&#40;&#41;&#41;)

[//]: # (              .le&#40;StringUtils.isNotBlank&#40;dto.getEndTime&#40;&#41;&#41;, BizBill::getCreateTime, dto.getEndTime&#40;&#41;&#41;)

[//]: # (              .last&#40;buildOrderSql&#40;dto.getSortField&#40;&#41;, dto.getSortOrder&#40;&#41;&#41;&#41;;)

[//]: # ()
[//]: # (       Page<BizBill> page = this.page&#40;dto.convertToPage&#40;&#41;, wrapper&#41;;)

[//]: # ()
[//]: # (       // 批量查类别名称)

[//]: # (       Map<Long, String> categoryNameMap = buildCategoryNameMap&#40;page.getRecords&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       // Entity → VO)

[//]: # (       List<BizBillVo> voList = page.getRecords&#40;&#41;.stream&#40;&#41;.map&#40;bill -> {)

[//]: # (           BizBillVo vo = new BizBillVo&#40;&#41;;)

[//]: # (           BeanUtils.copyProperties&#40;bill, vo&#41;;)

[//]: # (           if &#40;bill.getCategoryId&#40;&#41; != null&#41; {)

[//]: # (               vo.setCategoryName&#40;categoryNameMap.get&#40;bill.getCategoryId&#40;&#41;&#41;&#41;;)

[//]: # (           })

[//]: # (           return vo;)

[//]: # (       }&#41;.collect&#40;Collectors.toList&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       PageResult result = PageResult.fromPage&#40;page&#41;;)

[//]: # (       result.setList&#40;voList&#41;;)

[//]: # (       return result;)

[//]: # (  })

[//]: # ()
[//]: # (  // ==================== 详情 ====================)

[//]: # ()
[//]: # (  @Override)

[//]: # (  public BizBillDetailVo getBillDetail&#40;Long id&#41; {)

[//]: # (  BizBill bill = this.getById&#40;id&#41;;)

[//]: # (  if &#40;bill == null&#41; {)

[//]: # (  throw new ServiceException&#40;"票据不存在！"&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (       // 非管理员只能查看自己的票据)

[//]: # (       if &#40;!SecurityUtils.hasPermi&#40;"biz:bill:review"&#41;)

[//]: # (               && !SecurityUtils.getUsername&#40;&#41;.equals&#40;bill.getCreateBy&#40;&#41;&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"只能查看自己的票据！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       BizBillDetailVo vo = new BizBillDetailVo&#40;&#41;;)

[//]: # (       BeanUtils.copyProperties&#40;bill, vo&#41;;)

[//]: # ()
[//]: # (       // 设置状态文本)

[//]: # (       vo.setStatusText&#40;getStatusText&#40;bill.getStatus&#40;&#41;&#41;&#41;;)

[//]: # ()
[//]: # (       // 查类别名称)

[//]: # (       if &#40;bill.getCategoryId&#40;&#41; != null&#41; {)

[//]: # (           BizCategory category = categoryMapper.selectById&#40;bill.getCategoryId&#40;&#41;&#41;;)

[//]: # (           if &#40;category != null&#41; {)

[//]: # (               vo.setCategoryName&#40;category.getCategoryName&#40;&#41;&#41;;)

[//]: # (           })

[//]: # (       })

[//]: # ()
[//]: # (       // 查附件列表)

[//]: # (       List<BizBillFile> files = fileMapper.selectList&#40;)

[//]: # (           new LambdaQueryWrapper<BizBillFile>&#40;&#41;)

[//]: # (               .eq&#40;BizBillFile::getBillId, id&#41;)

[//]: # (               .orderByAsc&#40;BizBillFile::getSortOrder&#41;)

[//]: # (       &#41;;)

[//]: # (       vo.setFiles&#40;files.stream&#40;&#41;.map&#40;f -> {)

[//]: # (           BizBillFileVo fvo = new BizBillFileVo&#40;&#41;;)

[//]: # (           BeanUtils.copyProperties&#40;f, fvo&#41;;)

[//]: # (           // 生成预览和下载URL)

[//]: # (           fvo.setPreviewUrl&#40;"/api/bill/preview/" + f.getId&#40;&#41;&#41;;)

[//]: # (           fvo.setDownloadUrl&#40;"/api/bill/download/" + f.getId&#40;&#41;&#41;;)

[//]: # (           return fvo;)

[//]: # (       }&#41;.collect&#40;Collectors.toList&#40;&#41;&#41;&#41;;)

[//]: # ()
[//]: # (       // 查审核历史)

[//]: # (       List<BizAuditLog> logs = auditLogMapper.selectList&#40;)

[//]: # (           new LambdaQueryWrapper<BizAuditLog>&#40;&#41;)

[//]: # (               .eq&#40;BizAuditLog::getBillId, id&#41;)

[//]: # (               .orderByDesc&#40;BizAuditLog::getAuditTime&#41;)

[//]: # (       &#41;;)

[//]: # (       vo.setAuditLogs&#40;logs.stream&#40;&#41;.map&#40;l -> {)

[//]: # (           BizAuditLogVo lvo = new BizAuditLogVo&#40;&#41;;)

[//]: # (           BeanUtils.copyProperties&#40;l, lvo&#41;;)

[//]: # (           // 设置操作文本)

[//]: # (           lvo.setActionText&#40;"1".equals&#40;l.getAction&#40;&#41;&#41; ? "通过" : "退回"&#41;;)

[//]: # (           return lvo;)

[//]: # (       }&#41;.collect&#40;Collectors.toList&#40;&#41;&#41;&#41;;)

[//]: # ()
[//]: # (       return vo;)

[//]: # (  })

[//]: # ()
[//]: # (  // ==================== 编辑 ====================)

[//]: # ()
[//]: # (  @Override)

[//]: # (  public void updateBill&#40;BizBillDto dto&#41; {)

[//]: # (  checkNotAdmin&#40;&#41;;)

[//]: # (  BizBill bill = this.getById&#40;dto.getId&#40;&#41;&#41;;)

[//]: # (  if &#40;bill == null&#41; {)

[//]: # (  throw new ServiceException&#40;"票据不存在！"&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (       // 仅草稿或已退回可编辑)

[//]: # (       if &#40;!List.of&#40;"0", "3"&#41;.contains&#40;bill.getStatus&#40;&#41;&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"只能编辑草稿或已退回状态的票据！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 校验数据归属)

[//]: # (       if &#40;!SecurityUtils.getUsername&#40;&#41;.equals&#40;bill.getCreateBy&#40;&#41;&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"只能编辑自己的票据！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 保留字段不被 null 覆盖)

[//]: # (       if &#40;StringUtils.isNotBlank&#40;dto.getAttachment&#40;&#41;&#41;&#41; {)

[//]: # (           bill.setAttachment&#40;dto.getAttachment&#40;&#41;&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       bill.setTitle&#40;dto.getTitle&#40;&#41;&#41;;)

[//]: # (       bill.setCategoryId&#40;dto.getCategoryId&#40;&#41;&#41;;)

[//]: # (       bill.setAmount&#40;dto.getAmount&#40;&#41;&#41;;)

[//]: # (       bill.setDescription&#40;dto.getDescription&#40;&#41;&#41;;)

[//]: # (       bill.setUpdateBy&#40;SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (       bill.setUpdateTime&#40;new Date&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       if &#40;!this.updateById&#40;bill&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"系统错误，票据更新失败！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 仅当传入了新附件时才替换旧附件)

[//]: # (       if &#40;StringUtils.isNotBlank&#40;dto.getAttachment&#40;&#41;&#41;&#41; {)

[//]: # (           fileMapper.delete&#40;new LambdaQueryWrapper<BizBillFile>&#40;&#41;)

[//]: # (               .eq&#40;BizBillFile::getBillId, bill.getId&#40;&#41;&#41;&#41;;)

[//]: # (           saveAttachments&#40;bill.getId&#40;&#41;, dto.getAttachment&#40;&#41;&#41;;)

[//]: # (       })

[//]: # (  })

[//]: # ()
[//]: # (  // ==================== 提交审核 ====================)

[//]: # ()
[//]: # (  @Override)

[//]: # (  public void submitBill&#40;Long id&#41; {)

[//]: # (  checkNotAdmin&#40;&#41;;)

[//]: # (  BizBill bill = this.getById&#40;id&#41;;)

[//]: # (  if &#40;bill == null&#41; {)

[//]: # (  throw new ServiceException&#40;"票据不存在！"&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (       // 仅草稿或已退回可提交)

[//]: # (       if &#40;!List.of&#40;"0", "3"&#41;.contains&#40;bill.getStatus&#40;&#41;&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"只能提交草稿或已退回状态的票据！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 校验数据归属)

[//]: # (       if &#40;!SecurityUtils.getUsername&#40;&#41;.equals&#40;bill.getCreateBy&#40;&#41;&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"只能提交自己的票据！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 草稿有临时编号的，替换为正式编号（用主键ID保证并发唯一）)

[//]: # (       if &#40;StringUtils.isBlank&#40;bill.getBillNo&#40;&#41;&#41; || bill.getBillNo&#40;&#41;.startsWith&#40;"DRAFT-"&#41;&#41; {)

[//]: # (           bill.setBillNo&#40;generateBillNo&#40;bill.getId&#40;&#41;&#41;&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       bill.setStatus&#40;"1"&#41;;)

[//]: # (       bill.setUpdateBy&#40;SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (       bill.setUpdateTime&#40;new Date&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       if &#40;!this.updateById&#40;bill&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"系统错误，票据提交失败！"&#41;;)

[//]: # (       })

[//]: # (  })

[//]: # ()
[//]: # (  // ==================== 删除 ====================)

[//]: # ()
[//]: # (  @Override)

[//]: # (  public void deleteBill&#40;Long id&#41; {)

[//]: # (  checkNotAdmin&#40;&#41;;)

[//]: # (  BizBill bill = this.getById&#40;id&#41;;)

[//]: # (  if &#40;bill == null&#41; {)

[//]: # (  throw new ServiceException&#40;"票据不存在！"&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (       // 仅草稿可删除)

[//]: # (       if &#40;!"0".equals&#40;bill.getStatus&#40;&#41;&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"只能删除草稿状态的票据！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 校验数据归属)

[//]: # (       if &#40;!SecurityUtils.getUsername&#40;&#41;.equals&#40;bill.getCreateBy&#40;&#41;&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"只能删除自己的票据！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 先删附件，再删票据)

[//]: # (       fileMapper.delete&#40;new LambdaQueryWrapper<BizBillFile>&#40;&#41;)

[//]: # (           .eq&#40;BizBillFile::getBillId, id&#41;&#41;;)

[//]: # (       this.removeById&#40;id&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (  // ==================== 审核 ====================)

[//]: # ()
[//]: # (  @Override)

[//]: # (  public void reviewBill&#40;BizBillReviewDto dto&#41; {)

[//]: # (  // 校验 action 值合法性)

[//]: # (  if &#40;!List.of&#40;"1", "2"&#41;.contains&#40;dto.getAction&#40;&#41;&#41;&#41; {)

[//]: # (  throw new ServiceException&#40;"无效的审核结果，action 必须为 1（通过）或 2（退回）！"&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (       BizBill bill = this.getById&#40;dto.getBillId&#40;&#41;&#41;;)

[//]: # (       if &#40;bill == null&#41; {)

[//]: # (           throw new ServiceException&#40;"票据不存在！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 仅已提交状态可审核)

[//]: # (       if &#40;!"1".equals&#40;bill.getStatus&#40;&#41;&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"只能审核已提交状态的票据！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 更新票据审核信息)

[//]: # (       bill.setStatus&#40;dto.getAction&#40;&#41;.equals&#40;"1"&#41; ? "2" : "3"&#41;;)

[//]: # (       bill.setAuditBy&#40;SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (       bill.setAuditTime&#40;new Date&#40;&#41;&#41;;)

[//]: # (       bill.setAuditComment&#40;dto.getComment&#40;&#41;&#41;;)

[//]: # (       bill.setUpdateBy&#40;SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (       bill.setUpdateTime&#40;new Date&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       if &#40;!this.updateById&#40;bill&#41;&#41; {)

[//]: # (           throw new ServiceException&#40;"系统错误，审核失败！"&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       // 记录审核历史)

[//]: # (       BizAuditLog log = BizAuditLog.builder&#40;&#41;)

[//]: # (           .billId&#40;dto.getBillId&#40;&#41;&#41;)

[//]: # (           .action&#40;dto.getAction&#40;&#41;&#41;)

[//]: # (           .comment&#40;dto.getComment&#40;&#41;&#41;)

[//]: # (           .auditBy&#40;SecurityUtils.getUsername&#40;&#41;&#41;)

[//]: # (           .auditTime&#40;new Date&#40;&#41;&#41;)

[//]: # (           .build&#40;&#41;;)

[//]: # (       auditLogMapper.insert&#40;log&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (  // ==================== 附件 ====================)

[//]: # ()
[//]: # (  /**)

[//]: # (    * 解析附件路径字符串，创建附件记录)

[//]: # (    * @param billId 票据ID)

[//]: # (    * @param attachment 逗号分隔的附件路径)

[//]: # (      */)

[//]: # (      private void saveAttachments&#40;Long billId, String attachment&#41; {)

[//]: # (      if &#40;StringUtils.isBlank&#40;attachment&#41;&#41; {)

[//]: # (      return;)

[//]: # (      })

[//]: # ()
[//]: # (      String[] paths = attachment.split&#40;","&#41;;)

[//]: # (      for &#40;int i = 0; i < paths.length; i++&#41; {)

[//]: # (      String path = paths[i].trim&#40;&#41;;)

[//]: # (      if &#40;StringUtils.isBlank&#40;path&#41;&#41; {)

[//]: # (      continue;)

[//]: # (      })

[//]: # ()
[//]: # (           BizBillFile file = BizBillFile.builder&#40;&#41;)

[//]: # (               .billId&#40;billId&#41;)

[//]: # (               .fileName&#40;path.substring&#40;path.lastIndexOf&#40;"/"&#41; + 1&#41;&#41;)

[//]: # (               .filePath&#40;path&#41;)

[//]: # (               .sortOrder&#40;i&#41;)

[//]: # (               .createBy&#40;SecurityUtils.getUsername&#40;&#41;&#41;)

[//]: # (               .createTime&#40;new Date&#40;&#41;&#41;)

[//]: # (               .build&#40;&#41;;)

[//]: # (           fileMapper.insert&#40;file&#41;;)

[//]: # (      })

[//]: # (      })

[//]: # ()
[//]: # (  // ==================== 工具方法 ====================)

[//]: # ()
[//]: # (  /**)

[//]: # (    * 批量查询类别ID对应的类别名称)

[//]: # (      */)

[//]: # (      private String buildOrderSql&#40;String sortField, String sortOrder&#41; {)

[//]: # (      if &#40;sortField == null || sortField.isEmpty&#40;&#41;&#41; return "ORDER BY create_time DESC";)

[//]: # (      String col = switch &#40;sortField&#41; {)

[//]: # (      case "amount" -> "amount";)

[//]: # (      case "createTime" -> "create_time";)

[//]: # (      case "auditTime" -> "audit_time";)

[//]: # (      default -> "create_time";)

[//]: # (      };)

[//]: # (      String dir = "desc".equalsIgnoreCase&#40;sortOrder&#41; ? "DESC" : "ASC";)

[//]: # (      return "ORDER BY " + col + " " + dir;)

[//]: # (      })

[//]: # ()
[//]: # (  private Map<Long, String> buildCategoryNameMap&#40;List<BizBill> bills&#41; {)

[//]: # (  List<Long> categoryIds = bills.stream&#40;&#41;)

[//]: # (  .map&#40;BizBill::getCategoryId&#41;)

[//]: # (  .filter&#40;id -> id != null&#41;)

[//]: # (  .distinct&#40;&#41;)

[//]: # (  .collect&#40;Collectors.toList&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       if &#40;categoryIds.isEmpty&#40;&#41;&#41; {)

[//]: # (           return new java.util.HashMap<>&#40;&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       List<BizCategory> categories = categoryMapper.selectBatchIds&#40;categoryIds&#41;;)

[//]: # (       return categories.stream&#40;&#41;)

[//]: # (           .collect&#40;Collectors.toMap&#40;BizCategory::getCategoryId, BizCategory::getCategoryName, &#40;a, b&#41; -> a, java.util.HashMap::new&#41;&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (  /**)

[//]: # (    * 生成票据编号: BILL-yyyyMMdd-{billId})

[//]: # (    * 使用票据主键ID保证并发安全，避免批量提交时编号重复)

[//]: # (      */)

[//]: # (      private String generateBillNo&#40;Long billId&#41; {)

[//]: # (      String dateStr = new SimpleDateFormat&#40;"yyyyMMdd"&#41;.format&#40;new Date&#40;&#41;&#41;;)

[//]: # (      return String.format&#40;"BILL-%s-%04d", dateStr, billId&#41;;)

[//]: # (      })

[//]: # ()
[//]: # (  /**)

[//]: # (    * 获取状态文本)

[//]: # (      */)

[//]: # (      private String getStatusText&#40;String status&#41; {)

[//]: # (      if &#40;status == null&#41; return "未知";)

[//]: # (      switch &#40;status&#41; {)

[//]: # (      case "0": return "草稿";)

[//]: # (      case "1": return "已提交";)

[//]: # (      case "2": return "已通过";)

[//]: # (      case "3": return "已退回";)

[//]: # (      default: return "未知";)

[//]: # (      })

[//]: # (      })

[//]: # ()
[//]: # (  @Override)

[//]: # (  public List<TrendItemVo> getMonthlyTrend&#40;&#41; {)

[//]: # (  Calendar now = Calendar.getInstance&#40;&#41;;)

[//]: # (  int year = now.get&#40;Calendar.YEAR&#41;;)

[//]: # (  int month = now.get&#40;Calendar.MONTH&#41; + 1;)

[//]: # ()
[//]: # (       Calendar start = Calendar.getInstance&#40;&#41;;)

[//]: # (       start.set&#40;year, month - 1, 1, 0, 0, 0&#41;;)

[//]: # (       String startStr = new SimpleDateFormat&#40;"yyyy-MM-dd"&#41;.format&#40;start.getTime&#40;&#41;&#41;;)

[//]: # (       String endStr = new SimpleDateFormat&#40;"yyyy-MM-dd"&#41;.format&#40;now.getTime&#40;&#41;&#41;;)

[//]: # ()
[//]: # (       LambdaQueryWrapper<BizBill> trendWrapper = new LambdaQueryWrapper<BizBill>&#40;&#41;)

[//]: # (           .ge&#40;BizBill::getUpdateTime, startStr&#41;)

[//]: # (           .le&#40;BizBill::getUpdateTime, endStr&#41;)

[//]: # (           .ne&#40;BizBill::getStatus, "0"&#41;;)

[//]: # (       if &#40;SecurityUtils.hasPermi&#40;"*:*:*"&#41;&#41; {)

[//]: # (           // 超管看全量)

[//]: # (       } else if &#40;SecurityUtils.hasPermi&#40;"biz:bill:review"&#41;&#41; {)

[//]: # (           trendWrapper.eq&#40;BizBill::getAuditBy, SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (       } else {)

[//]: # (           trendWrapper.eq&#40;BizBill::getCreateBy, SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (       })

[//]: # (       List<BizBill> bills = this.list&#40;trendWrapper&#41;;)

[//]: # ()
[//]: # (       Map<String, Long> weekMap = new LinkedHashMap<>&#40;&#41;;)

[//]: # (       for &#40;int i = 1; i <= 4; i++&#41; {)

[//]: # (           weekMap.put&#40;"第" + i + "周", 0L&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       for &#40;BizBill bill : bills&#41; {)

[//]: # (           Calendar cal = Calendar.getInstance&#40;&#41;;)

[//]: # (           cal.setTime&#40;bill.getUpdateTime&#40;&#41;&#41;;)

[//]: # (           int dayOfMonth = cal.get&#40;Calendar.DAY_OF_MONTH&#41;;)

[//]: # (           String weekLabel = "第" + &#40;&#40;dayOfMonth - 1&#41; / 7 + 1&#41; + "周";)

[//]: # (           weekMap.merge&#40;weekLabel, 1L, Long::sum&#41;;)

[//]: # (       })

[//]: # ()
[//]: # (       List<TrendItemVo> result = new ArrayList<>&#40;&#41;;)

[//]: # (       weekMap.forEach&#40;&#40;label, count&#41; -> result.add&#40;new TrendItemVo&#40;label, count&#41;&#41;&#41;;)

[//]: # (       return result;)

[//]: # (  })

[//]: # ()
[//]: # (  @Override)

[//]: # (  public List<TrendItemVo> getCategoryAmountSummary&#40;&#41; {)

[//]: # (  LambdaQueryWrapper<BizBill> wrapper = new LambdaQueryWrapper<BizBill>&#40;&#41;)

[//]: # (  .eq&#40;BizBill::getStatus, "2"&#41;;)

[//]: # (  if &#40;SecurityUtils.hasPermi&#40;"*:*:*"&#41;&#41; {)

[//]: # (  // 超管看全量)

[//]: # (  } else if &#40;SecurityUtils.hasPermi&#40;"biz:bill:review"&#41;&#41; {)

[//]: # (  wrapper.eq&#40;BizBill::getAuditBy, SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (  } else {)

[//]: # (  wrapper.eq&#40;BizBill::getCreateBy, SecurityUtils.getUsername&#40;&#41;&#41;;)

[//]: # (  })

[//]: # (  List<BizBill> bills = this.list&#40;wrapper&#41;;)

[//]: # ()
[//]: # (       Map<Long, Long> amountMap = new LinkedHashMap<>&#40;&#41;;)

[//]: # (       Map<Long, String> nameMap = new LinkedHashMap<>&#40;&#41;;)

[//]: # ()
[//]: # (       for &#40;BizBill bill : bills&#41; {)

[//]: # (           Long cid = bill.getCategoryId&#40;&#41;;)

[//]: # (           if &#40;cid != null&#41; {)

[//]: # (               amountMap.merge&#40;cid, bill.getAmount&#40;&#41; != null ? bill.getAmount&#40;&#41;.longValue&#40;&#41; : 0L, Long::sum&#41;;)

[//]: # (               if &#40;!nameMap.containsKey&#40;cid&#41;&#41; {)

[//]: # (                   BizCategory cat = categoryMapper.selectById&#40;cid&#41;;)

[//]: # (                   nameMap.put&#40;cid, cat != null ? cat.getCategoryName&#40;&#41; : "未知"&#41;;)

[//]: # (               })

[//]: # (           })

[//]: # (       })

[//]: # ()
[//]: # (       return amountMap.entrySet&#40;&#41;.stream&#40;&#41;)

[//]: # (           .map&#40;e -> new TrendItemVo&#40;nameMap.getOrDefault&#40;e.getKey&#40;&#41;, "未知"&#41;, e.getValue&#40;&#41;&#41;&#41;)

[//]: # (           .collect&#40;Collectors.toList&#40;&#41;&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (  @Override)

[//]: # (  public ReviewerStatsVo getReviewerStats&#40;&#41; {)

[//]: # (  String username = SecurityUtils.getUsername&#40;&#41;;)

[//]: # (  ReviewerStatsVo vo = new ReviewerStatsVo&#40;&#41;;)

[//]: # ()
[//]: # (       // 待审核数量)

[//]: # (       vo.setPendingCount&#40;&#40;int&#41; this.count&#40;)

[//]: # (           new LambdaQueryWrapper<BizBill>&#40;&#41;.eq&#40;BizBill::getStatus, "1"&#41;&#41;&#41;;)

[//]: # ()
[//]: # (       // 今日通过/退回)

[//]: # (       String today = new SimpleDateFormat&#40;"yyyy-MM-dd"&#41;.format&#40;new Date&#40;&#41;&#41;;)

[//]: # (       int todayApproved = &#40;int&#41; this.count&#40;)

[//]: # (           new LambdaQueryWrapper<BizBill>&#40;&#41;)

[//]: # (               .eq&#40;BizBill::getAuditBy, username&#41;)

[//]: # (               .eq&#40;BizBill::getStatus, "2"&#41;)

[//]: # (               .ge&#40;BizBill::getAuditTime, today&#41;&#41;;)

[//]: # (       int todayRejected = &#40;int&#41; this.count&#40;)

[//]: # (           new LambdaQueryWrapper<BizBill>&#40;&#41;)

[//]: # (               .eq&#40;BizBill::getAuditBy, username&#41;)

[//]: # (               .eq&#40;BizBill::getStatus, "3"&#41;)

[//]: # (               .ge&#40;BizBill::getAuditTime, today&#41;&#41;;)

[//]: # (       vo.setTodayApproved&#40;todayApproved&#41;;)

[//]: # (       vo.setTodayRejected&#40;todayRejected&#41;;)

[//]: # ()
[//]: # (       // 通过率)

[//]: # (       int totalReviewed = todayApproved + todayRejected;)

[//]: # (       vo.setApprovalRate&#40;totalReviewed > 0)

[//]: # (           ? Math.round&#40;todayApproved * 100.0 / totalReviewed&#41; : 0&#41;;)

[//]: # ()
[//]: # (       // 积压预警: 超过3天未审核)

[//]: # (       Calendar cal = Calendar.getInstance&#40;&#41;;)

[//]: # (       cal.add&#40;Calendar.DAY_OF_MONTH, -3&#41;;)

[//]: # (       vo.setStalePending&#40;&#40;int&#41; this.count&#40;)

[//]: # (           new LambdaQueryWrapper<BizBill>&#40;&#41;)

[//]: # (               .eq&#40;BizBill::getStatus, "1"&#41;)

[//]: # (               .lt&#40;BizBill::getCreateTime, cal.getTime&#40;&#41;&#41;&#41;&#41;;)

[//]: # ()
[//]: # (       // 最近审核记录)

[//]: # (       List<BizBill> recentBills = this.list&#40;)

[//]: # (           new LambdaQueryWrapper<BizBill>&#40;&#41;)

[//]: # (               .eq&#40;BizBill::getAuditBy, username&#41;)

[//]: # (               .in&#40;BizBill::getStatus, "2", "3"&#41;)

[//]: # (               .orderByDesc&#40;BizBill::getAuditTime&#41;)

[//]: # (               .last&#40;"LIMIT 5"&#41;&#41;;)

[//]: # (       Map<Long, String> categoryNameMap = buildCategoryNameMap&#40;recentBills&#41;;)

[//]: # (       vo.setRecentReviews&#40;recentBills.stream&#40;&#41;.map&#40;bill -> {)

[//]: # (           BizBillVo billVo = new BizBillVo&#40;&#41;;)

[//]: # (           BeanUtils.copyProperties&#40;bill, billVo&#41;;)

[//]: # (           if &#40;bill.getCategoryId&#40;&#41; != null&#41; {)

[//]: # (               billVo.setCategoryName&#40;categoryNameMap.get&#40;bill.getCategoryId&#40;&#41;&#41;&#41;;)

[//]: # (           })

[//]: # (           return billVo;)

[//]: # (       }&#41;.collect&#40;Collectors.toList&#40;&#41;&#41;&#41;;)

[//]: # ()
[//]: # (       return vo;)

[//]: # (  })

[//]: # ()
[//]: # (  @Override)

[//]: # (  public UserBillStatsVo getUserBillStats&#40;&#41; {)

[//]: # (  String username = SecurityUtils.getUsername&#40;&#41;;)

[//]: # ()
[//]: # (       // 查询当前用户的所有票据)

[//]: # (       LambdaQueryWrapper<BizBill> wrapper = new LambdaQueryWrapper<BizBill>&#40;&#41;)

[//]: # (           .eq&#40;BizBill::getCreateBy, username&#41;;)

[//]: # (       List<BizBill> allBills = this.list&#40;wrapper&#41;;)

[//]: # (       )
[//]: # (       // 统计各状态数量)

[//]: # (       long draftCount = allBills.stream&#40;&#41;.filter&#40;b -> "0".equals&#40;b.getStatus&#40;&#41;&#41;&#41;.count&#40;&#41;;)

[//]: # (       long submittedCount = allBills.stream&#40;&#41;.filter&#40;b -> "1".equals&#40;b.getStatus&#40;&#41;&#41;&#41;.count&#40;&#41;;)

[//]: # (       long approvedCount = allBills.stream&#40;&#41;.filter&#40;b -> "2".equals&#40;b.getStatus&#40;&#41;&#41;&#41;.count&#40;&#41;;)

[//]: # (       long rejectedCount = allBills.stream&#40;&#41;.filter&#40;b -> "3".equals&#40;b.getStatus&#40;&#41;&#41;&#41;.count&#40;&#41;;)

[//]: # (       )
[//]: # (       // 计算已通过票据的总金额)

[//]: # (       java.math.BigDecimal totalAmount = allBills.stream&#40;&#41;)

[//]: # (           .filter&#40;b -> "2".equals&#40;b.getStatus&#40;&#41;&#41;&#41;)

[//]: # (           .map&#40;BizBill::getAmount&#41;)

[//]: # (           .filter&#40;amount -> amount != null&#41;)

[//]: # (           .reduce&#40;java.math.BigDecimal.ZERO, java.math.BigDecimal::add&#41;;)

[//]: # (       )
[//]: # (       return UserBillStatsVo.builder&#40;&#41;)

[//]: # (           .totalCount&#40;&#40;long&#41; allBills.size&#40;&#41;&#41;)

[//]: # (           .draftCount&#40;draftCount&#41;)

[//]: # (           .submittedCount&#40;submittedCount&#41;)

[//]: # (           .approvedCount&#40;approvedCount&#41;)

[//]: # (           .rejectedCount&#40;rejectedCount&#41;)

[//]: # (           .totalAmount&#40;totalAmount.setScale&#40;2, java.math.RoundingMode.HALF_UP&#41;.toString&#40;&#41;&#41;)

[//]: # (           .build&#40;&#41;;)

[//]: # (  })

[//]: # ()
[//]: # (})

