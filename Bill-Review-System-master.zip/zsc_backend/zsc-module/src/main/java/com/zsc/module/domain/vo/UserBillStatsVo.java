package com.zsc.module.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 个人票据统计信息
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserBillStatsVo {

    /** 全部票据数量 */
    private Long totalCount;

    /** 草稿数量 */
    private Long draftCount;

    /** 已提交数量 */
    private Long submittedCount;

    /** 已通过数量 */
    private Long approvedCount;

    /** 已退回数量 */
    private Long rejectedCount;

    /** 总金额（已通过） */
    private String totalAmount;
}
