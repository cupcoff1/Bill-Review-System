package com.zsc.module.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zsc.common.utils.SecurityUtils;
import com.zsc.module.common.exception.ServiceException;
import com.zsc.module.common.pagination.PageResult;
import com.zsc.module.domain.dto.BizBillDto;
import com.zsc.module.domain.dto.BizBillReviewDto;
import com.zsc.module.domain.dto.query.BizBillQueryDto;
import com.zsc.module.domain.entity.BizAuditLog;
import com.zsc.module.domain.entity.BizBill;
import com.zsc.module.domain.entity.BizBillFile;
import com.zsc.module.domain.entity.BizCategory;
import com.zsc.module.domain.vo.BizAuditLogVo;
import com.zsc.module.domain.vo.BizBillDetailVo;
import com.zsc.module.domain.vo.BizBillFileVo;
import com.zsc.module.domain.vo.BizBillVo;
import com.zsc.module.domain.vo.ReviewerStatsVo;
import com.zsc.module.domain.vo.TrendItemVo;
import com.zsc.module.domain.vo.UserBillStatsVo;
import com.zsc.module.mapper.BizAuditLogMapper;
import com.zsc.module.mapper.BizBillFileMapper;
import com.zsc.module.mapper.BizBillMapper;
import com.zsc.module.mapper.BizCategoryMapper;
import com.zsc.module.service.BizBillService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 票据表 服务实现类
 */
@Service
@Transactional
public class BizBillServiceImpl extends ServiceImpl<BizBillMapper, BizBill> implements BizBillService {

    @Autowired
    private BizBillFileMapper fileMapper;

    @Autowired
    private BizAuditLogMapper auditLogMapper;

    @Autowired
    private BizCategoryMapper categoryMapper;

    /**
     * 管理员禁止执行用户专属操作
     */
    private void checkNotAdmin() {
        if (SecurityUtils.hasPermi("biz:bill:review")) {
            throw new ServiceException("管理员不能执行用户操作！");
        }
    }

    // ==================== 新增 ====================

    @Override
    public void addBill(BizBillDto dto) {
        checkNotAdmin();
        BizBill bill = new BizBill();
        BeanUtils.copyProperties(dto, bill);

        bill.setCreateBy(SecurityUtils.getUsername());
        bill.setCreateTime(new Date());

        // 先保存草稿（用临时编号占位），再根据状态替换为正式编号
        bill.setBillNo("DRAFT-" + System.currentTimeMillis());

        if (!this.save(bill)) {
            throw new ServiceException("系统错误，票据保存失败！");
        }

        if ("1".equals(dto.getStatus())) {
            bill.setBillNo(generateBillNo(bill.getId()));
            this.updateById(bill);
        }

        // 保存附件记录
        saveAttachments(bill.getId(), dto.getAttachment());
    }

    // ==================== 查询列表 ====================

    @Override
    public PageResult<BizBillVo> queryBills(BizBillQueryDto dto) {
        LambdaQueryWrapper<BizBill> wrapper = new LambdaQueryWrapper<>();

        // 普通用户只查自己的票据
        if (!SecurityUtils.hasPermi("biz:bill:review")) {
            wrapper.eq(BizBill::getCreateBy, SecurityUtils.getUsername());
        }

        // 条件过滤
        if (StringUtils.isNotBlank(dto.getKeywords())) {
            wrapper.and(w -> w
                .like(BizBill::getTitle, dto.getKeywords())
                .or()
                .like(BizBill::getBillNo, dto.getKeywords())
            );
        }
        wrapper.eq(dto.getCategoryId() != null, BizBill::getCategoryId, dto.getCategoryId())
               .eq(StringUtils.isNotBlank(dto.getStatus()), BizBill::getStatus, dto.getStatus())
               .like(StringUtils.isNotBlank(dto.getAuditBy()), BizBill::getAuditBy, dto.getAuditBy())
               .like(StringUtils.isNotBlank(dto.getCreateBy()), BizBill::getCreateBy, dto.getCreateBy())
               .ge(dto.getMinAmount() != null, BizBill::getAmount, dto.getMinAmount())
               .le(dto.getMaxAmount() != null, BizBill::getAmount, dto.getMaxAmount())
               .ge(StringUtils.isNotBlank(dto.getStartTime()), BizBill::getCreateTime, dto.getStartTime())
               .le(StringUtils.isNotBlank(dto.getEndTime()), BizBill::getCreateTime, dto.getEndTime())
               .last(buildOrderSql(dto.getSortField(), dto.getSortOrder()));

        Page<BizBill> page = this.page(dto.convertToPage(), wrapper);

        // 批量查类别名称
        Map<Long, String> categoryNameMap = buildCategoryNameMap(page.getRecords());

        // Entity → VO
        List<BizBillVo> voList = page.getRecords().stream().map(bill -> {
            BizBillVo vo = new BizBillVo();
            BeanUtils.copyProperties(bill, vo);
            if (bill.getCategoryId() != null) {
                vo.setCategoryName(categoryNameMap.get(bill.getCategoryId()));
            }
            return vo;
        }).collect(Collectors.toList());

        PageResult result = PageResult.fromPage(page);
        result.setList(voList);
        return result;
    }

    // ==================== 详情 ====================

    @Override
    public BizBillDetailVo getBillDetail(Long id) {
        BizBill bill = this.getById(id);
        if (bill == null) {
            throw new ServiceException("票据不存在！");
        }

        // 非管理员只能查看自己的票据
        if (!SecurityUtils.hasPermi("biz:bill:review")
                && !SecurityUtils.getUsername().equals(bill.getCreateBy())) {
            throw new ServiceException("只能查看自己的票据！");
        }

        BizBillDetailVo vo = new BizBillDetailVo();
        BeanUtils.copyProperties(bill, vo);

        // 设置状态文本
        vo.setStatusText(getStatusText(bill.getStatus()));

        // 查类别名称
        if (bill.getCategoryId() != null) {
            BizCategory category = categoryMapper.selectById(bill.getCategoryId());
            if (category != null) {
                vo.setCategoryName(category.getCategoryName());
            }
        }

        // 查附件列表
        List<BizBillFile> files = fileMapper.selectList(
            new LambdaQueryWrapper<BizBillFile>()
                .eq(BizBillFile::getBillId, id)
                .orderByAsc(BizBillFile::getSortOrder)
        );
        vo.setFiles(files.stream().map(f -> {
            BizBillFileVo fvo = new BizBillFileVo();
            BeanUtils.copyProperties(f, fvo);
            // 生成预览和下载URL
            fvo.setPreviewUrl("/api/bill/preview/" + f.getId());
            fvo.setDownloadUrl("/api/bill/download/" + f.getId());
            return fvo;
        }).collect(Collectors.toList()));

        // 查审核历史
        List<BizAuditLog> logs = auditLogMapper.selectList(
            new LambdaQueryWrapper<BizAuditLog>()
                .eq(BizAuditLog::getBillId, id)
                .orderByDesc(BizAuditLog::getAuditTime)
        );
        vo.setAuditLogs(logs.stream().map(l -> {
            BizAuditLogVo lvo = new BizAuditLogVo();
            BeanUtils.copyProperties(l, lvo);
            // 设置操作文本
            lvo.setActionText("1".equals(l.getAction()) ? "通过" : "退回");
            return lvo;
        }).collect(Collectors.toList()));

        return vo;
    }

    // ==================== 编辑 ====================

    @Override
    public void updateBill(BizBillDto dto) {
        checkNotAdmin();
        BizBill bill = this.getById(dto.getId());
        if (bill == null) {
            throw new ServiceException("票据不存在！");
        }

        // 仅草稿或已退回可编辑
        if (!List.of("0", "3").contains(bill.getStatus())) {
            throw new ServiceException("只能编辑草稿或已退回状态的票据！");
        }

        // 校验数据归属
        if (!SecurityUtils.getUsername().equals(bill.getCreateBy())) {
            throw new ServiceException("只能编辑自己的票据！");
        }

        // 保留字段不被 null 覆盖
        if (StringUtils.isNotBlank(dto.getAttachment())) {
            bill.setAttachment(dto.getAttachment());
        }

        bill.setTitle(dto.getTitle());
        bill.setCategoryId(dto.getCategoryId());
        bill.setAmount(dto.getAmount());
        bill.setDescription(dto.getDescription());
        bill.setUpdateBy(SecurityUtils.getUsername());
        bill.setUpdateTime(new Date());

        if (!this.updateById(bill)) {
            throw new ServiceException("系统错误，票据更新失败！");
        }

        // 仅当传入了新附件时才替换旧附件
        if (StringUtils.isNotBlank(dto.getAttachment())) {
            fileMapper.delete(new LambdaQueryWrapper<BizBillFile>()
                .eq(BizBillFile::getBillId, bill.getId()));
            saveAttachments(bill.getId(), dto.getAttachment());
        }
    }

    // ==================== 提交审核 ====================

    @Override
    public void submitBill(Long id) {
        checkNotAdmin();
        BizBill bill = this.getById(id);
        if (bill == null) {
            throw new ServiceException("票据不存在！");
        }

        // 仅草稿或已退回可提交
        if (!List.of("0", "3").contains(bill.getStatus())) {
            throw new ServiceException("只能提交草稿或已退回状态的票据！");
        }

        // 校验数据归属
        if (!SecurityUtils.getUsername().equals(bill.getCreateBy())) {
            throw new ServiceException("只能提交自己的票据！");
        }

        // 草稿有临时编号的，替换为正式编号（用主键ID保证并发唯一）
        if (StringUtils.isBlank(bill.getBillNo()) || bill.getBillNo().startsWith("DRAFT-")) {
            bill.setBillNo(generateBillNo(bill.getId()));
        }

        bill.setStatus("1");
        bill.setUpdateBy(SecurityUtils.getUsername());
        bill.setUpdateTime(new Date());

        if (!this.updateById(bill)) {
            throw new ServiceException("系统错误，票据提交失败！");
        }
    }
