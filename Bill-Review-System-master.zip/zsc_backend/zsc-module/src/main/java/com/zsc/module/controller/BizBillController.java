package com.zsc.module.controller;

import com.zsc.common.annotation.Log;
import com.zsc.common.enums.BusinessType;
import com.zsc.common.config.RuoYiConfig;
import com.zsc.common.utils.StringUtils;
import com.zsc.common.utils.file.FileUtils;
import com.zsc.module.common.pagination.PageResult;
import com.zsc.module.common.response.ResultVo;
import com.zsc.module.domain.dto.BizBillDto;
import com.zsc.module.domain.dto.BizBillReviewDto;
import com.zsc.module.domain.dto.query.BizBillQueryDto;
import com.zsc.module.domain.entity.BizBillFile;
import com.zsc.module.domain.vo.BizBillDetailVo;
import com.zsc.module.domain.vo.BizBillVo;
import com.zsc.module.domain.vo.ReviewerStatsVo;
import com.zsc.module.domain.vo.TrendItemVo;
import com.zsc.module.domain.vo.UserBillStatsVo;
import com.zsc.module.mapper.BizBillFileMapper;
import com.zsc.module.service.BizBillService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 票据控制器
 * 普通用户: 新增/编辑/提交/删除/查询自己的票据
 * 管理员: 审核票据 + 查看全部
 */
@Slf4j
@Tag(name = "票据管理")
@Validated
@RestController
@RequestMapping("/api/bill")
public class BizBillController {

    @Autowired
    private BizBillService bizBillService;

    @Autowired
    private BizBillFileMapper fileMapper;

    // ==================== 查询 ====================

    /**
     * 分页条件查询票据列表
     */
    @Operation(summary = "查询票据列表")
    @PreAuthorize("@ss.hasPermi('biz:bill:list')")
    @PostMapping("/query")
    public ResultVo<PageResult<BizBillVo>> query(@RequestBody BizBillQueryDto queryDto) {
        PageResult pageResult = bizBillService.queryBills(queryDto);
        log.info(pageResult.getList().toString());
        return ResultVo.ok(pageResult);
    }

    @Operation(summary = "审核员仪表盘统计")
    @PreAuthorize("@ss.hasPermi('biz:bill:review')")
    @GetMapping("/reviewer-stats")
    public ResultVo<ReviewerStatsVo> reviewerStats() {
        return ResultVo.ok(bizBillService.getReviewerStats());
    }

    @Operation(summary = "本月提交趋势")
    @PreAuthorize("@ss.hasPermi('biz:bill:list')")
    @GetMapping("/trend")
    public ResultVo<List<TrendItemVo>> trend() {
        return ResultVo.ok(bizBillService.getMonthlyTrend());
    }

    @Operation(summary = "各类别金额汇总")
    @PreAuthorize("@ss.hasPermi('biz:bill:list')")
    @GetMapping("/category-summary")
    public ResultVo<List<TrendItemVo>> categorySummary() {
        return ResultVo.ok(bizBillService.getCategoryAmountSummary());
    }

    /**
     * 获取个人票据统计信息（各状态数量）
     */
    @Operation(summary = "获取个人票据统计")
    @PreAuthorize("@ss.hasPermi('biz:bill:list')")
    @GetMapping("/my-stats")
    public ResultVo<UserBillStatsVo> getMyStats() {
        return ResultVo.ok(bizBillService.getUserBillStats());
    }

    /**
     * 查看票据详情（含附件列表和审核历史）
     */
    @Operation(summary = "获取票据详情")
    @PreAuthorize("@ss.hasPermi('biz:bill:query')")
    @GetMapping("/{id}")
    public ResultVo<BizBillDetailVo> get(@PathVariable @Min(value = 1, message = "票据ID不能小于1") Long id) {
        return ResultVo.ok(bizBillService.getBillDetail(id));
    }

    // ==================== 新增/编辑/提交/删除 ====================

    /**
     * 新增票据
     * status="0" 保存草稿，status="1" 直接提交
     */
    @Operation(summary = "新增票据")
    @PreAuthorize("@ss.hasPermi('biz:bill:add')")
    @Log(title = "票据管理", businessType = BusinessType.INSERT)
    @PostMapping
    public ResultVo add(@Valid @RequestBody BizBillDto dto) {
        bizBillService.addBill(dto);
        return ResultVo.ok(dto.getStatus().equals("0") ? "草稿已保存" : "提交成功");
    }

    /**
     * 修改票据（仅限草稿或已退回状态）
     */
    @Operation(summary = "修改票据")
    @PreAuthorize("@ss.hasPermi('biz:bill:add')")
    @Log(title = "票据管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public ResultVo update(@Valid @RequestBody BizBillDto dto) {
        bizBillService.updateBill(dto);
        return ResultVo.ok("修改成功");
    }

    /**
     * 提交草稿进入审核流程
     */
    @Operation(summary = "提交审核")
    @PreAuthorize("@ss.hasPermi('biz:bill:add')")
    @Log(title = "票据管理", businessType = BusinessType.UPDATE)
    @PostMapping("/submit/{id}")
    public ResultVo submit(@PathVariable @Min(value = 1, message = "票据ID不能小于1") Long id) {
        bizBillService.submitBill(id);
        return ResultVo.ok("提交成功");
    }

    /**
     * 删除草稿票据及其附件
     */
    @Operation(summary = "删除票据")
    @PreAuthorize("@ss.hasPermi('biz:bill:remove')")
    @Log(title = "票据管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{id}")
    public ResultVo delete(@PathVariable @Min(value = 1, message = "票据ID不能小于1") Long id) {
        bizBillService.deleteBill(id);
        return ResultVo.ok("删除成功");
    }

    // ==================== 审核 ====================

    /**
     * 审核票据（通过或退回）
     */
    @Operation(summary = "审核票据")
    @PreAuthorize("@ss.hasPermi('biz:bill:review')")
    @Log(title = "票据管理", businessType = BusinessType.UPDATE)
    @PostMapping("/review")
    public ResultVo review(@Valid @RequestBody BizBillReviewDto dto) {
        bizBillService.reviewBill(dto);
        return ResultVo.ok("审核成功");
    }

    @Operation(summary = "批量审核票据")
    @PreAuthorize("@ss.hasPermi('biz:bill:review')")
    @Log(title = "票据管理", businessType = BusinessType.UPDATE)
    @PostMapping("/batch-review")
    public ResultVo batchReview(@RequestBody Map<String, Object> body) {
        List<Long> ids = ((List<Integer>) body.get("ids")).stream().map(Long::valueOf).toList();
        String action = (String) body.get("action");
        if (!"1".equals(action) && !"2".equals(action)) {
            return ResultVo.fail("无效的审核结果");
        }
        String comment = (String) body.getOrDefault("comment", "");
        int count = 0;
        for (Long id : ids) {
            BizBillReviewDto dto = new BizBillReviewDto();
            dto.setBillId(id);
            dto.setAction(action);
            dto.setComment(comment);
            try {
                bizBillService.reviewBill(dto);
                count++;
            } catch (Exception ignored) {}
        }
        return ResultVo.ok("批量审核完成: " + count + "/" + ids.size());
    }

    // ==================== 附件预览和下载 ====================

    /**
     * 在线预览附件（支持PDF、图片等格式）
     * 所有状态的票据都可以预览附件
     */
    @Operation(summary = "在线预览附件")
    @PreAuthorize("@ss.hasPermi('biz:bill:query')")
    @GetMapping("/preview/{fileId}")
    public void previewFile(@PathVariable Long fileId, HttpServletResponse response) {
        try {
            BizBillFile file = fileMapper.selectById(fileId);
            if (file == null) {
                throw new RuntimeException("文件不存在");
            }

            // 验证权限：只能预览自己票据的附件或管理员可以预览所有
            com.zsc.module.domain.entity.BizBill bill = bizBillService.getById(file.getBillId());
            if (bill == null) {
                throw new RuntimeException("关联票据不存在");
            }

            if (!com.zsc.common.utils.SecurityUtils.hasPermi("biz:bill:review")
                    && !com.zsc.common.utils.SecurityUtils.getUsername().equals(bill.getCreateBy())) {
                throw new RuntimeException("无权访问此附件");
            }

            // 获取文件路径
            String filePath = RuoYiConfig.getProfile() + file.getFilePath();
            String fileName = file.getFileName();
            String fileType = file.getFileType();

            // 根据文件类型设置Content-Type
            setPreviewContentType(response, fileType, fileName);

            // 输出文件流
            FileUtils.writeBytes(filePath, response.getOutputStream());
            response.flushBuffer();
        } catch (Exception e) {
            log.error("预览文件失败", e);
            throw new RuntimeException("预览文件失败: " + e.getMessage());
        }
    }

    /**
     * 下载附件（仅已审核通过的票据可下载）
     */
    @Operation(summary = "下载附件")
    @PreAuthorize("@ss.hasPermi('biz:bill:query')")
    @GetMapping("/download/{fileId}")
    public void downloadFile(@PathVariable Long fileId, HttpServletResponse response, HttpServletRequest request) {
        try {
            BizBillFile file = fileMapper.selectById(fileId);
            if (file == null) {
                throw new RuntimeException("文件不存在");
            }

            // 验证权限：只能下载自己票据的附件或管理员可以下载所有
            com.zsc.module.domain.entity.BizBill bill = bizBillService.getById(file.getBillId());
            if (bill == null) {
                throw new RuntimeException("关联票据不存在");
            }

            if (!com.zsc.common.utils.SecurityUtils.hasPermi("biz:bill:review")
                    && !com.zsc.common.utils.SecurityUtils.getUsername().equals(bill.getCreateBy())) {
                throw new RuntimeException("无权访问此附件");
            }

            // 检查票据状态：只有已审核通过的票据才能下载
            if (!"2".equals(bill.getStatus())) {
                String statusText = getStatusText(bill.getStatus());
                String message = String.format("当前票据状态为【%s】，只有【已通过】状态的票据才能下载附件。\n" +
                        "您可以先预览附件查看内容，待审核通过后再进行下载。", statusText);
                throw new RuntimeException(message);
            }

            // 获取文件路径
            String filePath = RuoYiConfig.getProfile() + file.getFilePath();
            String fileName = file.getFileName();

            // 设置响应头为下载
            response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
            FileUtils.setAttachmentResponseHeader(response, fileName);

            // 输出文件流
            FileUtils.writeBytes(filePath, response.getOutputStream());
            response.flushBuffer();
        } catch (Exception e) {
            log.error("下载文件失败", e);
            throw new RuntimeException("下载文件失败: " + e.getMessage());
        }
    }

    /**
     * 批量下载已通过票据的所有附件
     */
    @Operation(summary = "批量下载票据附件")
    @PreAuthorize("@ss.hasPermi('biz:bill:query')")
    @GetMapping("/batch-download/{billId}")
    public ResultVo<List<String>> batchDownloadFiles(@PathVariable Long billId) {
        try {
            // 验证权限
            com.zsc.module.domain.entity.BizBill bill = bizBillService.getById(billId);
            if (bill == null) {
                return ResultVo.<List<String>>fail(null);
            }

            if (!com.zsc.common.utils.SecurityUtils.hasPermi("biz:bill:review")
                    && !com.zsc.common.utils.SecurityUtils.getUsername().equals(bill.getCreateBy())) {
                return ResultVo.<List<String>>fail(null);
            }

            // 检查票据状态
            if (!"2".equals(bill.getStatus())) {
                return ResultVo.<List<String>>fail(null);
            }

            // 查询所有附件
            List<BizBillFile> files = fileMapper.selectList(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<BizBillFile>()
                    .eq(BizBillFile::getBillId, billId)
                    .orderByAsc(BizBillFile::getSortOrder)
            );

            if (files.isEmpty()) {
                return ResultVo.<List<String>>fail(null);
            }

            // 生成下载链接列表
            List<String> downloadUrls = files.stream()
                .map(f -> String.format("/api/bill/download/%d", f.getId()))
                .collect(java.util.stream.Collectors.toList());

            return ResultVo.ok(downloadUrls);
        } catch (Exception e) {
            log.error("批量下载失败", e);
            return ResultVo.<List<String>>fail(null);
        }
    }

    /**
     * 设置预览文件的Content-Type
     */
    private void setPreviewContentType(HttpServletResponse response, String fileType, String fileName) {
        if (StringUtils.isBlank(fileType)) {
            // 从文件名推断类型
            if (fileName != null) {
                if (fileName.toLowerCase().endsWith(".pdf")) {
                    response.setContentType("application/pdf");
                } else if (fileName.toLowerCase().endsWith(".jpg") || fileName.toLowerCase().endsWith(".jpeg")) {
                    response.setContentType("image/jpeg");
                } else if (fileName.toLowerCase().endsWith(".png")) {
                    response.setContentType("image/png");
                } else if (fileName.toLowerCase().endsWith(".gif")) {
                    response.setContentType("image/gif");
                } else if (fileName.toLowerCase().endsWith(".bmp")) {
                    response.setContentType("image/bmp");
                } else if (fileName.toLowerCase().endsWith(".webp")) {
                    response.setContentType("image/webp");
                } else if (fileName.toLowerCase().endsWith(".txt")) {
                    response.setContentType("text/plain;charset=UTF-8");
                } else {
                    response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
                }
            } else {
                response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
            }
        } else {
            // 根据fileType设置
            switch (fileType.toLowerCase()) {
                case "pdf":
                    response.setContentType("application/pdf");
                    break;
                case "jpg":
                case "jpeg":
                    response.setContentType("image/jpeg");
                    break;
                case "png":
                    response.setContentType("image/png");
                    break;
                case "gif":
                    response.setContentType("image/gif");
                    break;
                case "bmp":
                    response.setContentType("image/bmp");
                    break;
                case "webp":
                    response.setContentType("image/webp");
                    break;
                case "txt":
                    response.setContentType("text/plain;charset=UTF-8");
                    break;
                default:
                    response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
                    break;
            }
        }
    }

    /**
     * 获取状态文本
     */
    private String getStatusText(String status) {
        switch (status) {
            case "0": return "草稿";
            case "1": return "已提交";
            case "2": return "已通过";
            case "3": return "已退回";
            default: return "未知";
        }
    }
}
