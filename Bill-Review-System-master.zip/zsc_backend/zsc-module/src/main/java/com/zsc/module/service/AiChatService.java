package com.zsc.module.service;

import com.zsc.module.domain.dto.AiChatDto;
import com.zsc.module.domain.vo.AiChatResponseVo;

/**
 * AI交互服务接口
 */
public interface AiChatService {

    /**
     * AI简单问答 - 票据相关信息查询
     * @param chatDto 包含用户输入和可选的票据ID
     * @return AI回复结果
     */
    AiChatResponseVo chat(AiChatDto chatDto);

    /**
     * 获取票据信息摘要（用于AI问答上下文）
     * @param billId 票据ID
     * @return 票据信息摘要
     */
    String getBillSummary(Long billId);
}
