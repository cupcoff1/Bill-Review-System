package com.zsc.module.controller;

import com.zsc.common.annotation.Log;
import com.zsc.common.enums.BusinessType;
import com.zsc.module.common.response.ResultVo;
import com.zsc.module.domain.dto.AiChatDto;
import com.zsc.module.domain.vo.AiChatResponseVo;
import com.zsc.module.service.AiChatService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * AI交互控制器
 * 提供票据相关的AI问答功能
 */
@Slf4j
@Tag(name = "AI交互")
@RestController
@RequestMapping("/api/ai")
public class AiChatController {

    @Autowired
    private AiChatService aiChatService;

    /**
     * AI智能问答
     * 支持票据相关信息查询和常见问题解答
     */
    @Operation(summary = "AI智能问答")
    @PreAuthorize("@ss.hasPermi('biz:bill:list')")
    @Log(title = "AI交互", businessType = BusinessType.OTHER)
    @PostMapping("/chat")
    public ResultVo<AiChatResponseVo> chat(@Valid @RequestBody AiChatDto chatDto) {
        log.info("用户提问: {}", chatDto.getUserInput());
        AiChatResponseVo response = aiChatService.chat(chatDto);
        return ResultVo.ok(response);
    }

    /**
     * 获取票据信息摘要（用于AI问答上下文）
     */
    @Operation(summary = "获取票据信息摘要")
    @PreAuthorize("@ss.hasPermi('biz:bill:query')")
    @GetMapping("/bill-summary/{billId}")
    public ResultVo<String> getBillSummary(@PathVariable Long billId) {
        String summary = aiChatService.getBillSummary(billId);
        if (summary == null) {
            return ResultVo.fail("未找到该票据信息");
        }
        return ResultVo.ok(summary);
    }
}
