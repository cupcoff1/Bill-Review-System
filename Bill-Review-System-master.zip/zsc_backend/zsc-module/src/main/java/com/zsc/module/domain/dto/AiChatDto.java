package com.zsc.module.domain.dto;

import lombok.Data;

@Data
public class AiChatDto {
    private String userInput;  // 用户输入的信息
    private Long billId;       // 关联的账单ID（可选，用于上下文）

}
