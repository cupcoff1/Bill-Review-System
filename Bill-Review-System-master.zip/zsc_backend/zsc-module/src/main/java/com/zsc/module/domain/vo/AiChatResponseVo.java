package com.zsc.module.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * AI交互响应结果
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AiChatResponseVo {

    /** 回复内容 */
    private String answer;

    /** 是否成功 */
    private Boolean success;

    /** 票据ID（如果有） */
    private Long billId;

    /** 建议操作 */
    private String suggestion;
}
